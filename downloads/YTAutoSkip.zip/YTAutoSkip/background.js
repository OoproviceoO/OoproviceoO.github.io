// 收到「請按這個位置」→ 暫時用偵錯模式送出真實滑鼠點擊 → 立刻解除
// 只會在 YouTube 分頁上、只有出現略過按鈕時才執行

const busy = new Set();

async function realClick(tabId, x, y) {
  if (busy.has(tabId)) return;
  busy.add(tabId);
  const target = { tabId };
  try {
    await chrome.debugger.attach(target, '1.3');
    const base = { x, y, button: 'left', clickCount: 1 };
    await chrome.debugger.sendCommand(target, 'Input.dispatchMouseEvent', { type: 'mouseMoved', x, y });
    await chrome.debugger.sendCommand(target, 'Input.dispatchMouseEvent', { type: 'mousePressed', ...base });
    await chrome.debugger.sendCommand(target, 'Input.dispatchMouseEvent', { type: 'mouseReleased', ...base });
    chrome.storage.local.get({ skipped: 0 }, (v) => chrome.storage.local.set({ skipped: v.skipped + 1 }));
  } catch (e) {
    console.warn('[YT略過] 點擊失敗：', e && e.message);
  } finally {
    try { await chrome.debugger.detach(target); } catch (_) {}
    setTimeout(() => busy.delete(tabId), 1500);
  }
}

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg && msg.type === 'click' && sender.tab && sender.tab.id != null &&
      /^https:\/\/www\.youtube\.com\//.test(sender.tab.url || '')) {
    realClick(sender.tab.id, msg.x, msg.y);
  }
});
