// YouTube 自動略過廣告 v2.0 — 只在 youtube.com 執行，不連網、不收集任何資料
(function () {
  'use strict';

  const DEFAULTS = { enabled: true, speedUp: true, mute: true, adSpeed: 16 };
  let cfg = { ...DEFAULTS };
  chrome.storage.sync.get(DEFAULTS, (v) => { cfg = v; });
  chrome.storage.onChanged.addListener((changes) => {
    for (const k in changes) if (k in cfg) cfg[k] = changes[k].newValue;
  });

  const SKIP_SELECTORS = [
    '.ytp-skip-ad-button',
    '.ytp-ad-skip-button',
    '.ytp-ad-skip-button-modern',
    '.ytp-ad-skip-button-slot button',
    'button[id^="skip-button"]',
  ];
  const OVERLAY_CLOSE_SELECTORS = [
    '.ytp-ad-overlay-close-button',
    '.ytp-ad-overlay-close-container',
  ];

  let inAd = false, savedRate = 1, savedMuted = false, lastAsk = 0;

  function findVisible(selectors) {
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el && el.offsetParent !== null) {
        const r = el.getBoundingClientRect();
        if (r.width > 0 && r.height > 0) return { el, r };
      }
    }
    return null;
  }

  // 請背景程式用「真實滑鼠」按這個位置
  function askRealClick(r) {
    const now = Date.now();
    if (now - lastAsk < 1500) return;
    lastAsk = now;
    try {
      chrome.runtime.sendMessage({
        type: 'click',
        x: Math.round(r.left + r.width / 2),
        y: Math.round(r.top + r.height / 2),
      });
    } catch (_) {}
  }

  function tick() {
    const player = document.querySelector('#movie_player, .html5-video-player');
    const video = document.querySelector('video');
    if (!player || !video) return;

    const adShowing = player.classList.contains('ad-showing') ||
                      player.classList.contains('ad-interrupting');

    if (!cfg.enabled) {
      if (inAd) { inAd = false; video.playbackRate = savedRate; video.muted = savedMuted; }
      return;
    }

    // 1. 略過按鈕：用真實點擊按下去
    const skip = findVisible(SKIP_SELECTORS);
    if (skip) askRealClick(skip.r);

    // 2. 橫幅廣告關閉鈕（這個一般點擊就有效）
    const close = findVisible(OVERLAY_CLOSE_SELECTORS);
    if (close) close.el.click();

    // 3. 廣告中：靜音＋加速
    if (adShowing) {
      if (!inAd) {
        inAd = true;
        savedRate = video.playbackRate || 1;
        savedMuted = video.muted;
      }
      if (cfg.mute) video.muted = true;
      if (cfg.speedUp && video.playbackRate !== cfg.adSpeed) video.playbackRate = cfg.adSpeed;
    } else if (inAd) {
      inAd = false;
      video.playbackRate = savedRate;
      video.muted = savedMuted;
    }
  }

  setInterval(tick, 300);
})();
