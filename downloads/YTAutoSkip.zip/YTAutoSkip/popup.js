const DEFAULTS = { enabled: true, speedUp: true, mute: true, adSpeed: 16 };
const $ = (id) => document.getElementById(id);

function refreshOpts() {
  $('opts').classList.toggle('disabled', !$('enabled').checked);
  $('adSpeed').disabled = !$('speedUp').checked;
}

chrome.storage.sync.get(DEFAULTS, (v) => {
  $('enabled').checked = v.enabled;
  $('mute').checked = v.mute;
  $('speedUp').checked = v.speedUp;
  $('adSpeed').value = String(v.adSpeed);
  refreshOpts();
});

chrome.storage.local.get({ skipped: 0 }, (v) => { $('count').textContent = v.skipped; });

for (const id of ['enabled', 'mute', 'speedUp']) {
  $(id).addEventListener('change', () => {
    chrome.storage.sync.set({ [id]: $(id).checked });
    refreshOpts();
  });
}
$('adSpeed').addEventListener('change', () => {
  chrome.storage.sync.set({ adSpeed: Number($('adSpeed').value) });
});
